import sqlite3
import logging
from pydicom import dcmread, dataset
import os
import os.path
import re
import shutil
import pynetdicom._config
from pynetdicom import AE, evt, AllStoragePresentationContexts, StoragePresentationContexts
from pynetdicom.sop_class import (
    PatientRootQueryRetrieveInformationModelGet,
    PatientRootQueryRetrieveInformationModelFind,
    PatientRootQueryRetrieveInformationModelMove,
    CTImageStorage
)
# import pkg_resources
import hashlib
import pickle
import time
import csv
import sys
import zipfile
from logging.handlers import RotatingFileHandler

#
# define logging with colors for stderr, uses separate class for this
#
class CustomFormatter(logging.Formatter):

    grey = "\x1b[38;20m"
    yellow = "\x1b[33;20m"
    red = "\x1b[31;20m"
    bold_red = "\x1b[31;1m"
    reset = "\x1b[0m"
    format = "%(levelname)-5s %(asctime)s [%(filename)-15s:%(lineno)-4s][%(funcName)-30s]\t%(message)s"

    FORMATS = {
        logging.DEBUG: grey + format + reset,
        logging.INFO: yellow + format + reset,
        logging.WARNING: yellow + format + reset,
        logging.ERROR: red + format + reset,
        logging.CRITICAL: bold_red + format + reset
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


log = logging.getLogger(__name__)
FILE_LOGFORMAT = "%(levelname)-5s %(asctime)s [%(filename)-15s:%(lineno)-4s][%(funcName)-30s]\t%(message)s"
log.setLevel(logging.ERROR)

# logging to stderr with colours
ch = logging.StreamHandler(sys.stderr)
ch.setFormatter(CustomFormatter())
log.addHandler(ch)

# file logging, only ERRORs are logged
fh = RotatingFileHandler("pyconquest_error.log", maxBytes=(100000), backupCount=1)
fh.setFormatter(logging.Formatter(FILE_LOGFORMAT))
fh.setLevel(logging.ERROR)
log.addHandler(fh)

class pyconquest:
    """Class  ConquestDB is used to read and write (interact) with a conquest PACS database

    Written by René Monshouwer
    2021
    """
    __name_to_tablename = {'Series': 'DICOMseries',
                           'Image': 'DICOMimages',
                           'Patient': 'DICOMpatients',
                           'Study': 'DICOMstudies',
                           'WorkList': 'DICOMworklist'}
    __extra_imagetable_columns = ['ObjectFile', 'ElementCount', 'ElementList', 'Nfractions',
                                  'UniqueFOR_UID', 'ReferencedSeriesUID', 'ReferencedSOPUID', 'DatabaseTimeStamp', 'hash']
    __prev_seriesuid = ''
    __prev_studyuid = ''
    __prev_patientid = ''
    __db_design = {}
    __truncate_colnames = True
    __compute_hash = False
    __write_to_database_when_receiving_dicom_data = True
    __instance_creation_time = ''
    try:
        # __version__ = pkg_resources.get_distribution("pyconquest").version
        __version__ = 'Unknown'
    except:
        __version__ = 'Unknown'
    data_directory = ''
    sql_inifile_name = ''
    database_filename = ''
    conn_pacs = ''
    roi_filter_flags = re.IGNORECASE
    exclude_filter = [r'^Z\d', r'^Ext', 'ISOC', 'QME', 'NP']
    include_filter = ['']
    last_seriesuid_loaded = ''

    def __init__(self, data_directory='data', sql_inifile_name='dicom.sql', database_filename='conquest.db',
                 connect_and_read_sql=True, loglevel='ERROR', compute_hash=False):
        """Create instance of pyconquest to interact with the database

        :param: data_directory : name of directory where the dicom files are stored, DEFAULT : data
        :param: sql_inifilename : name of the ini file where of database definition, DEFAULT : dicom.sql
        :param: database_filename : filename of the sqllite databasefile : DEFAULT : conquest.db
        :param: connect_and_read_sql : if True the database  is opened and the sql ini file is read, DEFAULT : True
        :param: loglevel : determines the loglevel, chooce from 'ERROR', 'INFO' or 'DEBUG', DEFAULT : ERROR
        :param: compute_hash : set to True to compute the hash for RTPLAN/RTDOSE/RTSTRUCT, DEFAULT : False
        """
        self.data_directory = data_directory
        self.sql_inifile_name = sql_inifile_name
        self.database_filename = database_filename
        self.__compute_hash = compute_hash
        self.__instance_creation_time = time.time()

        if loglevel == 'ERROR':
            log.level = logging.ERROR
        elif loglevel == 'DEBUG':
            log.level = logging.DEBUG
        elif loglevel == 'INFO':
            log.level = logging.INFO

        if connect_and_read_sql:
            self.__read_conquest_sql_inifile(self.sql_inifile_name)
            self.connect_db()
        log.info("Created pyconquest({}) with dir:({}); db:({});ini:({}) "
                 .format(self.__version__, data_directory, database_filename, sql_inifile_name))

    #
    #   some general multi purpose database interaction routines
    #

    def connect_db(self):
        """Open connection to the sqlite database, database filename defined during instance creation"""
        self.conn_pacs = sqlite3.connect(self.database_filename)
        log.info('Connected to ' + self.database_filename)
        # if the database is new, so empty recreate the tables this can save a step and is logical
        result = self.execute_db_query("SELECT name FROM sqlite_master WHERE type='table' AND lower(name)='dicomseries' ")
        if not result:
            log.info('Creating tables because sqlite database is empty')
            self.create_standard_dicom_tables()

    def close_db(self):
        """Close connection to the sqlite database"""
        self.conn_pacs.close()
        log.info('Closed connection to ' + self.database_filename)
        timediff = time.time() - self.__instance_creation_time
        log.info('Time elapsed : {:.1f} seconds ({:.2f} min)'.format(float(timediff), float(timediff / 60.0)))

    def execute_db_query(self, query, return_list_from_col=None):
        """Executes sqlite query on the opened database, and returns the result

        :param: query : query to be exceuted on the sqlite database
        :param: return_list_form_co : when set a list is returned of this columnname
        :returns: query result in the form of al list of dicts
        """
        query_result = None
        try:
            cursor = self.conn_pacs.cursor()
            cursor.execute(query)
            self.conn_pacs.commit()
            data = cursor.fetchall()
            cols = cursor.description
            query_result = [dict(line) for line in [zip([column[0] for column in cols], row) for row in data]]
            log.debug('Query : ' + query)
            log.debug('Result: ' + str(query_result))
        except Exception as e:
            log.error('exception ' + str(e) + '\nencountered in execution of db query: ' + query)

        if return_list_from_col is None:
            return query_result
        else:
            result = [row[return_list_from_col] for row in query_result]
            return result

    def insert_dict(self, tablename, datadict, exceptions={}, default_format='character varying(128)'):
        """
        Inserts a dict and creates a table if it not exists

        :param: tablename: name of table to store dict in
        :param: datadict: dict to store
        :return: nothing
        """
        query = self.create_insertquery(tablename, datadict)
        try:
            cursor = self.conn_pacs.cursor()
            cursor.execute(query)
            self.conn_pacs.commit()
        except Exception as e:
            if str(e).startswith('no such table') == True:
                log.info("Now creating table : {} to insert dict in".format(tablename))
                buildquery = self.create_buildquery(tablename, datadict,
                                                    exceptions=exceptions, default_format=default_format)
                cursor = self.conn_pacs.cursor()
                cursor.execute(buildquery)
                self.conn_pacs.commit()
                # now write anyway
                cursor = self.conn_pacs.cursor()
                cursor.execute(query)
                self.conn_pacs.commit()
            else:  # something else is wrong
                log.error("Error {} when inserting dict {} into table {}".format(str(e), datadict, tablename))

    def load_csv_to_table(self, filename, tablename, first_row_are_columnnames=True, key_translation={}, delimiter=';'):
        """
                Loads a csv file and inserts in into a table using insert_dict
                A routine to be used to load data in the db to combine/join with pacs data

                :param: filename : name of the csv file to open
                :param: tablename: name of table to store csv file in
                :param: first_row_are_columnnames: not implemented yet
                :param: key_translation: dictionary to convert column name in csv file to the column name in the db
                :param: delimiter: delimiter used in csv file, default ;
                :return: nothing
                example of key:translation : {'aantal fracties':'aantal_fracties','1e*':'eerste_bestraling'}
                """
        try:
            with open(filename, 'r') as f:
                dict_reader = csv.DictReader(f, delimiter=delimiter)
                list_of_dict = list(dict_reader)
                nrows = 1
                for row in list_of_dict:
                    filtered_row = {k: v.replace('"', '') for k, v in row.items()}
                    for key, value in key_translation.items():
                        if key in filtered_row.keys():
                            filtered_row[value] = filtered_row[key]
                            del filtered_row[key]
                        else:
                            log.info("Trying to replace '{}' but this key is not found".format(key))
                    self.insert_dict(tablename, filtered_row)
                    nrows = nrows + 1

                log.info("Read file : {} and inserted {} rows".format(filename, nrows))
        except FileNotFoundError:
            log.error("Could not find file: {}, Please check the file path.".format(filename))

    def __delete_table(self, tablename):
        """"Delete table with given name"""
        try:
            cur = self.conn_pacs.cursor()
            cur.execute('DROP TABLE IF EXISTS ' + tablename)
            self.conn_pacs.commit()
        except Exception as e:
            log.error('failed to drop table : ' + tablename)

    def __check_if_table_contains(self, tablename, colname, value):
        """Check if the table contains a certain row with specific value

        :param: tablename : name of the table
        :param: colname : name of the column of the value to be tested
        :param: value : value to test

        :returns: True or False depending on whether the row already exists"""

        cur = self.conn_pacs.cursor()
        query = 'SELECT * FROM ' + tablename + ' WHERE ' + colname + ' = \"' + value.strip() + '\"'
        cur.execute(query)
        row = cur.fetchone()
        if row is None:
            return False
        else:
            return True

    def create_insertquery(self, table, myDict):
        """Returns string with the format of an insertquery for sqlite to insert given dict in table called : table

        :param: table : name of the table to insert into
        :param: myDict : a Dict with columname/value pairs to enter into the insertquery
        :returns: string formatted as an insert query"""

        myDict = self.__convert_listvalues_to_conquest_style(myDict)
        columns_string = ('(' + ','.join(myDict.keys()) + ')').replace("-", "_")
        values_string = ('("' + '","'.join(map(str, myDict.values())) + '")').replace("\'", " ")
        sql = """INSERT INTO %s %s VALUES %s""" % (table, columns_string, values_string)
        return sql

    def create_buildquery(self, table, mydict, exceptions={}, default_format='character varying(128)'):
        """Returns string with the format of an buildquery for sqlite to create a table with colnames as given
                in the dict, default all columns are formatted as 'character varying(128)

                :param: table : name of the table to build
                :param: myDict : a Dict with columname/value pairs to to create the buildquery, values are ignored
                :param: exceptions : dictionary with exceptions : example : {'col1':'int'} makes col1 an int
                :param: default_format : default type of column : DEFAULT : character varying(128)
                :returns: string formatted as an table build query"""
        # columns_string = (' character varying(128),'.join(mydict.keys()) + ' character varying(128)').replace("-", "_")
        columns_string = ''
        for b in mydict:
            if b in exceptions:
                fm = exceptions[b]
            else:
                fm = default_format
            columns_string = columns_string + "{} {},".format(b, fm)

        sql = """CREATE TABLE {} ({})""".format(table, columns_string[:-1].replace("-", "_"))
        return sql

    #
    # below conquest specific routines
    #

    def __convert_listvalues_to_conquest_style(self, Dict):
        """Scans all items in a dict, and converts a list value to a string formatted as el1\\el2\\el3 etc.
        ; this conforms to the original conquest style"""
        for key, val in Dict.items():
            if str(val).startswith("[") is True and key not in self.__extra_imagetable_columns:
                val = str(val).replace('[', '').replace(']', '').replace(',', "\\").strip()
                Dict[key] = val
        return Dict

    def add_column_to_database(self, tablename, column_definition):
        """ Add an individual column to the database, should be done before calling create_standard_dicom_tables()

            :param: tablename : name of the table to add the column to
            :param: column_definition : definition of the column example : ['0x0020', '0x000e', 'SeriesInst']"""

        if not isinstance(column_definition[0], list):
            column_definition = [column_definition]

        for col in column_definition:
            try:
                self.__db_design[tablename].append(col)
                log.info('Added column {} to table {}'.format(col, tablename))
            except Exception:
                log.error('failed to add column {} to table {}'.format(col, tablename))

    def __read_conquest_sql_inifile(self, filename):
        """reads in the conquest style .sql file where the db is defined, follows original file format"""
        if os.path.exists(filename):
            with open(filename) as file:
                lines = file.readlines()
                lines = [line.rstrip() for line in lines]
            file.close()
        else:
            self.__set_default_database()
            return

        for line in lines:
            # comment lines
            if line.startswith("#") or line.startswith("/*") or line.startswith("*/"):
                continue
            # definition of tablename
            if line.startswith("*"):
                tablename = line.replace("*", "")
                tablename = self.__name_to_tablename[tablename]
                list_of_rows = []
                continue

            # end of table def
            if line.startswith("}"):
                log.info('reading table ' + tablename + ' from inifile:' + filename)
                self.__db_design[tablename] = list_of_rows
                continue

            stripped_line = re.sub("\s+", ' ', line)
            if stripped_line.startswith(" {"):
                col = (line.replace("\t{", "").replace("}", "").replace("{", '').replace(" ", "").split(","))
                if self.__truncate_colnames:
                    col[2] = col[2].replace('"', '').replace(' ', '')[0:10]
                list_of_rows.append(col[0:3])

    def __create_tabledict(self, tablename, ds):
        tabledict = {}
        for item in self.__db_design[tablename]:
            try:
                elem = ds[item[0], item[1]]
                if len(item) == 6:
                    val = elem[item[3]][(item[4], item[5])].value
                elif len(item) == 9:
                    val = elem[item[3]][(item[4], item[5])][item[6]][(item[7], item[8])].value
                else:
                    val = elem.value
            except Exception:
                val = ''
            tabledict[item[2].replace('\"', '')] = val
        return tabledict

    def write_tags(self, ds, filename='', check_existing=True):
        """Analyses the given already read in dicom tags, and inserts the appropriate data into the sqlitedatabase
        it optionally checks before insert if the row already exists (based on the keyvalue of the row) if so, no re-insert is done.
        Only for the DICOMimages table is Timestamp table is updated with the current time ( time of the rewrite ).
        For large databases and initial rebuild, use check_existing=False to speed up

        :param: ds : the dicom tags from the file, in the pydicom format
        :param: filename : the filename of the file that was read (to insert into the DICOMimages.ObjectFile column)
        :param: check_existing : if True, a check is done before inserting the row into the table, default TRUE
        """
        sopinstanceuid = ds['0x0008', '0x0018'].value

        if check_existing:
            row_exists = self.__check_if_table_contains('DICOMimages', 'SOPInstanc', sopinstanceuid)
        else:
            row_exists = False

        if not row_exists:
            imagedict = self.__create_tabledict('DICOMimages', ds)
            imagedict['ObjectFile'] = filename
            imagedict.update(self.__extra_dicom_tags(ds, filename))
            query = self.create_insertquery('DICOMimages', imagedict)
            self.execute_db_query(query)
        else:
            # update timestamp in case of rewrite of the data
            updatequery = """update DICOMimages set DatabaseTimeStamp=\'{}\' where SOPInstanc=\'{}\'""". \
                format(time.time(), sopinstanceuid)
            self.execute_db_query(updatequery)

        seriesuid = ds['0x0020', '0x000e'].value
        if not (seriesuid == self.__prev_seriesuid):
            self.__prev_seriesuid = seriesuid
            if not self.__check_if_table_contains('DICOMseries', 'SeriesInst', seriesuid):
                seriesdict = self.__create_tabledict('DICOMseries', ds)
                # if a unique FOR_UID was extracted from RTSTRUCT, add to series table also
                if 'UniqueFOR_UID' in imagedict:
                    seriesdict['FrameOfRef'] = imagedict['UniqueFOR_UID']
                if 'ReferencedSeriesUID' in imagedict:
                    seriesdict['Referenced'] = imagedict['ReferencedSeriesUID']
                query = self.create_insertquery('DICOMseries', seriesdict)
                self.execute_db_query(query)

            studyuid = ds['0x0020', '0x000d'].value
            if not (studyuid == self.__prev_studyuid):
                self.__prev_studyuid = studyuid
                if not self.__check_if_table_contains('DICOMstudies', 'Studyinsta', studyuid):
                    studydict = self.__create_tabledict('DICOMstudies', ds)
                    query = self.create_insertquery('DICOMstudies', studydict)
                    self.execute_db_query(query)

                patientid = ds['0x0010', '0x0020'].value
                if not (patientid == self.__prev_patientid):
                    self.__prev_patientid = patientid
                    if not self.__check_if_table_contains('DICOMpatients', 'Patientid', patientid):
                        patientdict = self.__create_tabledict('DICOMpatients', ds)
                        query = self.create_insertquery('DICOMpatients', patientdict)
                        self.execute_db_query(query)

    def create_standard_dicom_tables(self):
        """Destroys (if necessary) and recreates empty tables according to the database definition of this instance"""
        for tablename in self.__db_design:
            tablelist = self.__db_design[tablename]
            colnames = {}
            for item in tablelist:
                colnames[item[2]] = 'dummy'

            # as an excepion, add extra column to images table
            if tablename == 'DICOMimages':
                for colname in self.__extra_imagetable_columns:
                    colnames[colname] = 'dummy'

            query = self.create_buildquery(tablename, colnames)
            self.__delete_table(tablename)
            self.execute_db_query(query)

        self.__create_db_views()
        self.__create_db_index_tables()

    def rebuild_database_from_dicom(self, mrn=None, compute_only_missing=True, check_existing=True):
        """Rebuild the sqlite database by scanning the dicom data directory

        :param: mrn : if given, only the data from that directory / patient MRN is put in the database
        :param: ComputeOnlyMissing : if True a directory/MRN is only processed if there is NO entry in the database
         with that number default : True
        :param: check_existing : if True, a check is done when inserting rows in the db. put to False to speed up
            initial database rebuilding
        :returns: number of scanned files
         """
        if mrn is None:
            directory = self.data_directory
        else:
            directory = '{}/{}'.format(self.data_directory, mrn)

        already_present = self.execute_db_query(query='select PatientID from dicompatients',
                                                return_list_from_col='PatientID')
        counter = 0
        string_startingpoint = len(self.data_directory) + 1
        for root, dirs, files in os.walk(directory, topdown=True):
            mrn = root[len(self.data_directory) + 1:]
            if (mrn in already_present) and (compute_only_missing is True):
                log.info('Skipping Directory, PatientID already in database: ' + str(mrn))
                continue

            for name in files:
                full_filename = os.path.join(root, name)
                log.info('Processing ... ' + full_filename)
                try:
                    counter = counter + 1
                    ds = dcmread(full_filename)
                    self.write_tags(ds, full_filename[string_startingpoint:], check_existing=check_existing)
                except Exception as e:
                    log.error(str(e))

        self.database_postprocessing()
        return counter

    def store_dicom_file(self, filename, remove_after_store=False, sopinstance_as_filename=False, force_patientid=None):
        """Places dicom file in proper directory in data directory and updates database

        :param: filename : name of the dicom file to be placed in database
        :param: remove_after_store : determines if file is deleted after storing it ( default : FALSE )
        :param: sopinstance_as_filename : if set to True the sopuid will become the new filename ( default : FALSE )
        :param: force_patientid : if set the patientid is replaced by the given string ( default None )
        """
        try:
            ds = dcmread(filename)
            
            # force patientid if not none to value, and add old one to database column
            # to create the column add below columndefinition and do rebuild_standard_dicom_tables:
            # -> c.add_column_to_database(tablename='DICOMimages', column_definition=['0x0011', '0x0020', 'OLDMRN']) <-
            # note ! the column with the old data is only added to the database, not to the file !
            patientid_is_changed = False
            if force_patientid is not None:
                if ds[0x0010, 0x0020].value != force_patientid:
                    ds.add_new([0x0011, 0x0020], 'LO', ds[0x0010, 0x0020].value ) # write old tag to private tag
                    log.info('Converting PatientID from {} to {}'.format(ds[0x0010, 0x0020].value, force_patientid))
                    ds[0x0010, 0x0020].value = force_patientid
                    patientid_is_changed = True

            patientid = ds[0x0010, 0x0020].value

            if sopinstance_as_filename:
                SOPInstanceUID = ds[0x0008, 0x0018].value
                target_base_filename = "{}.dcm".format(SOPInstanceUID)
            else:
                target_base_filename = os.path.basename(filename)

            target_filename = "{}/{}/{}".format(self.data_directory, patientid, target_base_filename)
            target_filename_db = "{}/{}".format(patientid, target_base_filename)
            path = "{}/{}".format(self.data_directory, patientid)
            if not os.path.exists(path):
                os.makedirs(path)
                log.info("Directory " + path + " Created ")

            shutil.copy(filename, target_filename)
            log.info('stored file : {} in database at location: {}'.format(filename, target_filename))

            # actually alter the tag in the file if force patientid is applied
            if patientid_is_changed:
                self.change_tag(target_filename, tag='PatientID', new_value=force_patientid, create=False)
                log.info('changed patientID of  file : {}  to {} '.format(target_filename, force_patientid))

            if remove_after_store:
                os.remove(filename)
                log.info('removed file : {}'.format(filename))
            self.write_tags(ds, target_filename_db)

            # write last serieuid to class property
            self.last_seriesuid_loaded = ds[0x0020, 0x000e].value

        except Exception as e:
            log.error('Exception encountered in store_dicom_file: ' + str(e))

    def store_dicom_files_from_directory(self, directory_name, remove_after_store=False, sopinstance_as_filename=False,
                                         unzip=True, unzipdir='./unpack', force_patientid=None):
        """Scans the directory and runs store_dicom_file on all files. Can handle nested directories

        Stores the file in the dicom file tree and updates the sql database with the tags for every file in directory
        or subdirectories

        :param: directory_name : name of the directory where the files are that should be stored
        :param: remove_after_store : determines if file is deleted after storing it ( default : FALSE )
        :param: sopinstance_as_filename : if set to True the sopuid will become the new filename ( default : FALSE )
        :param: unzip (default TRUE) unzips a zip file to a temporary location before reading in the data
        :param: unzipdir : directory to unzip data in, directory should exist otherwise there is an exit
        :param: force_patientid : if set the patientid is replaced by the given string ( default None )
         """

        if os.path.exists(directory_name):
            for root, dirs, files in os.walk(directory_name, topdown=True):
                for name in files:
                    full_filename = os.path.join(root, name)
                    log.info('Processing ... ' + full_filename)

                    if zipfile.is_zipfile(full_filename) and unzip == True:
                        print('this is a zipfile')
                        if not os.path.isdir(unzipdir):
                            log.error('Unzip directory does not exist, so not doing anything')
                            exit()
                        else:
                            # remove all files
                            log.info('clearing the unzip directory')
                            for root2, dirs2, files2 in os.walk(unzipdir):
                                for f in files2:
                                    os.unlink(os.path.join(root2, f))
                                for d in dirs2:
                                    shutil.rmtree(os.path.join(root2, d))

                            log.info('unzipping file : {} to {}'.format(full_filename, unzipdir))
                            #unzip zipfile
                            with zipfile.ZipFile(full_filename, "r") as zip_ref:
                                zip_ref.extractall(unzipdir)

                            self.store_dicom_files_from_directory(directory_name=unzipdir,unzip=False,
                                                                  force_patientid=force_patientid)

                            log.info('clearing the unzip directory again')
                            for root2, dirs2, files2 in os.walk(unzipdir):
                                for f in files2:
                                    os.unlink(os.path.join(root2, f))
                                for d in dirs2:
                                    shutil.rmtree(os.path.join(root2, d))

                    else:
                        self.store_dicom_file(full_filename, remove_after_store=remove_after_store,
                                    sopinstance_as_filename=sopinstance_as_filename, force_patientid=force_patientid)
                        
            log.info('Processed {} files'.format(len(files)))
            return 1
        else:
            log.error('Directory  : {} does not exist'.format(directory_name))
            return -1

    def __extra_dicom_tags(self, ds, filename):
        """Save some tags contained into the database

        :param: ds : dicom tags of a dicom file as read by pydicom.dcmread
        :returns: a dict with extra parameters
        """
        returndict = {}
        returndict['DatabaseTimeStamp'] = time.time()
        dicomtype = ds[0x0008, 0x0060].value
        if dicomtype == 'RTSTRUCT':
            contours = ds[0x3006, 0x0020].value
            contournamelist = []
            FrameOfReferenceUID_List = []
            for c in contours:
                contournamelist.append(str(c[0x3006, 0x0026].value).replace("'", '').replace("\"", ""))
                FrameOfReferenceUID_List.append(c[0x3006, 0x0024].value)
            unique_frame_of_ref = list(set(FrameOfReferenceUID_List))
            returndict['ElementList'] = contournamelist
            returndict['ElementCount'] = len(contournamelist)
            if len(unique_frame_of_ref) == 1:
                returndict['UniqueFOR_UID'] = unique_frame_of_ref[0]
            else:
                returndict['UniqueFOR_UID'] = ''

            if self.__compute_hash:
                # change the tags to make insensitive for anonimisation
                ds.walk(self.__change_ReferencedSOPInstanceUID, recursive=True)
                # hash only of contoursequence
                returndict['hash'] = hashlib.md5(pickle.dumps(ds[0x3006, 0x0039].value)).hexdigest()

            try:
                referenced_seriesuid = ds[0x3006, 0x0010][0][0x3006, 0x0012][0][0x3006, 0x0014][0][0x0020, 0x000e].value
                returndict['ReferencedSeriesUID'] = referenced_seriesuid
            except:
                log.error('Error when extracting referenced_seriesuid')

        elif dicomtype == 'RTPLAN':
            FractionGroupSequence = ds[0x300a, 0x0070].value
            nr_fractions_list = []
            nr_beams_list = []
            fraction_list_counter = 0
            fractiongroupnumber_of_beamnumber = {}
            per_fraction_beamnr_of_beamnumber = {}
            for FractionGroup in FractionGroupSequence:
                # general info per fractiongroup
                nr_fractions_list.append(FractionGroup[0x300a, 0x0078].value)
                nr_beams_list.append(FractionGroup[0x300a, 0x0080].value)
                # loop over all beams belonging to this group and store fractiongroup/beamnr in dicts
                referenced_beam_list = FractionGroup[0x300c, 0x0004].value
                per_fractiongroup_beamcounter = 0
                for referenced_beam in referenced_beam_list:
                    fractiongroupnumber_of_beamnumber[
                        int(referenced_beam[0x300c, 0x0006].value)] = fraction_list_counter
                    per_fraction_beamnr_of_beamnumber[
                        int(referenced_beam[0x300c, 0x0006].value)] = per_fractiongroup_beamcounter
                    per_fractiongroup_beamcounter = per_fractiongroup_beamcounter + 1
                fraction_list_counter = fraction_list_counter + 1

            BeamSequence = ds[0x300a, 0x00b0].value
            Beam_properties_list = []
            beamcounter = 0
            string_with_beamMU = ''
            for Beam in BeamSequence:
                try:
                    fractiongroupnumber = fractiongroupnumber_of_beamnumber[beamcounter + 1]
                    per_fraction_beamnr = per_fraction_beamnr_of_beamnumber[beamcounter + 1]
                    Beam_properties_list.append([
                        Beam[0x300a, 0x00c2].value,  # beam name
                        Beam[0x300a, 0x00c4].value,  # beam type
                        Beam[0x300a, 0x00c6].value,  # radiation type
                        Beam[0x300a, 0x00d0].value,  # number of wedges
                        Beam[0x300a, 0x0110].value,  # number of Control Points
                        Beam[0x300a, 0x0111][0][0x300a, 0x0114].value,  # energy of CP 0 of beam
                        Beam[0x300a, 0x0111][0][0x300a, 0x011e].value,  # gantry angle of CP 0 of beam
                        ds[0x300a, 0x0070][fractiongroupnumber][0x300c, 0x0004][per_fraction_beamnr][
                            0x300a, 0x00084].value,  # beam Dose
                        ds[0x300a, 0x0070][fractiongroupnumber][0x300c, 0x0004][per_fraction_beamnr][
                            0x300a, 0x00086].value,  # beam MU
                        str(Beam[0x300a, 0x0111][0][0x300a, 0x012c].value) # isocenter_position of CP 0 of beam
                    ])
                    string_with_beamMU += str(
                        ds[0x300a, 0x0070][fractiongroupnumber][0x300c, 0x0004][per_fraction_beamnr][
                            0x300a, 0x00086].value) + '_'
                except Exception as e:
                    log.error('Error: "{}" when extracting individual beam data from RTPLAN file'.format(str(e)))
                beamcounter = beamcounter + 1

            # return only the value if there is only 1 FractionGroup, otherwise the list
            if len(nr_fractions_list) == 1:
                returndict['Nfractions'] = nr_fractions_list[0]
            else:
                returndict['Nfractions'] = nr_fractions_list

            if len(nr_beams_list) == 1:
                returndict['ElementCount'] = nr_beams_list[0]
            else:
                returndict['ElementCount'] = nr_beams_list

            if len(Beam_properties_list) == 1:
                returndict['ElementList'] = Beam_properties_list[0]
            else:
                returndict['ElementList'] = Beam_properties_list

            # RTPLAN has only the hash of the beam sequence
            if self.__compute_hash:
                # create a string that contains beamMU and all cp info of the plan for hashing purpose
                sequence_to_hash = string_with_beamMU + self.__rtplan_to_string(ds[0x300a, 0x00b0].value)
                returndict['hash'] = hashlib.md5(pickle.dumps(sequence_to_hash)).hexdigest()

            try:
                ReferencedSOPUID = ds[0x300c, 0x0060][0][0x0008, 0x1155].value
                # ReferencedSOPUID = ds[0x0008, 0x1110][0][0x0008, 0x1155].value
                returndict['ReferencedSOPUID'] = ReferencedSOPUID
            except Exception as e:
                log.error('Error when extracting referenced_seriesuid of RTSTRUCT from RTPLAN file')

        elif dicomtype == 'RTDOSE':
            try:
                ReferencedSOPUID = ds[0x300c, 0x0002][0][0x0008, 0x1155].value
                returndict['ReferencedSOPUID'] = ReferencedSOPUID
            except:
                log.error('Error when extracting referenced_seriesuid of RTPLAN from RTDOSE file')

            if self.__compute_hash:
                returndict['hash'] = hashlib.md5(pickle.dumps(ds.PixelData)).hexdigest()

        elif dicomtype == 'REG':
            try:
                # This is the seriesUID of the CT that is part of the REG ( for elekta XVI )
                returndict['ReferencedSeriesUID'] = ds[0x008, 0x1115][0][0x0020, 0x000e].value
                # THis is the SerieUID of the CBCT that is part of the REG ( for elekta XVI )
                returndict['ElementList'] = ds[0x008, 0x1115][1][0x0020, 0x000e].value
            except:
                log.error('Error when extracting from REG')

        return returndict

    def calculate_robust_hash(self,  seriesuid=''):
        """" compute a more robust hash for rtstructs
        puts all contour data in one string and makes hash, then combines all hashes and hashes again

        :param filename: filename to read from
        :param seriesuid : seriesuid of rtstruct
        :returns : tag value as a string
         """
        file_query = "select ObjectFile,ImagePat from dicomimages where seriesinst=\"{}\"".format(seriesuid)
        #file_query = "select ObjectFile,seriesinst from dicomimages where Modality='RTSTRUCT'".format(seriesuid)
        return_list = self.execute_db_query(file_query)
        if len(return_list) == 0:
            log.error('No item found with this seriesuid to calculate hash from '.format(seriesuid))
            return

        filename = "{}/{}".format(self.data_directory, return_list[0]['ObjectFile'])
        ds = dcmread(filename)
        dicomtype = ds[0x0008, 0x0060].value
        if dicomtype == 'RTSTRUCT':
            log.info('Calculating robust rtstruct hash from file : {}'.format(filename))
            cumulative_contour_string = ''
            contours = ds[0x3006, 0x0039].value
            for c in contours:
                cs = ''
                if (0x3006, 0x0040) in c:
                    for seq in c[0x3006, 0x0040].value:
                        cs = cs + str(seq[0x3006, 0x0050].value)
                cumulative_contour_string = cumulative_contour_string + hashlib.md5(cs.encode('utf-8')).hexdigest()

            retval = hashlib.md5(cumulative_contour_string.encode('utf-8')).hexdigest()
            log.info('Computed hash : {}, now updating DICOMimages table'.format(retval))
            update_query="update dicomimages set hash='{}' where seriesinst='{}'".format(retval,seriesuid)
            self.execute_db_query(update_query)

        else:
            log.error('wrong dicom type')
            retval=''
        return retval

    def read_single_tag(self, filename='', tag=None):
        """" simple functionality to read a single tag from a dicom file

        :param filename: filename to read from
        :param tag : tag to read in the format of a tuple : default is : ('0x3253', '1000')
        :returns : tag value as a string
         """

        if tag is None:
            tag = ('0x3253', '1000')  # example : private tag in varian RTPLAN
        ds = dcmread(filename)
        log.info('Reading tag {} from file : {}'.format(tag, filename))
        try:
            elem = ds[tag]
            val = elem.value
        except Exception as e:
            val = ''
            print('exception encountered:' + str(e))
        return val

    def __rtplan_to_string(self, ds):
        # converts beamsequence to a string that is hashable and should be identical for identical rtplans
        string_to_hash = ''
        for beam in ds:
            try:
                string_to_hash += str(beam[0x300a, 0x0110].value) + '_'  # nr of cp of beam
                for cp in beam[0x300a, 0x0111].value:
                    string_to_hash += str(cp[0x300a, 0x011e].value) + '_'  # gantry
                    string_to_hash += str(cp[0x300a, 0x0130].value) + '_'  # SSD of cp
                    string_to_hash += str(cp[0x300a, 0x0134].value) + '_'  # cumulative meterset weight
                    string_to_hash += str(cp[0x300a, 0x011a][0][0x300a, 0x011c].value) + '_'  # asymX
                    string_to_hash += str(cp[0x300a, 0x011a][1][0x300a, 0x011c].value) + '_'  # asymY
                    string_to_hash += str(cp[0x300a, 0x011a][2][0x300a, 0x011c].value)
            except Exception as e:
                log.info('Error: "{}" when concatenating rtplan info to string for hashing'.format(str(e)))
        return string_to_hash

    def __change_ReferencedSOPInstanceUID(self, ds, element):
        if element.keyword == 'ReferencedSOPInstanceUID':
            ds.ReferencedSOPInstanceUID = ''
            
    def delete_series(self, seriesuid='', query=None, delete_files=False, delete_only_files=False, mrn=None):
        """Deletes a single or multiple series from the disk and from the database

        :param: seriesuid : a single string (one seriesuid) or a list of seriesuids of series that should be deleted
        :param: query : a query that should return SeriesInst with the series to delete
        :param: delete_files : if set to True, the files are physically removed from disk (deleted), default=False
        :param: mrn : delete for the given mrn in a fast manner, so only all the database entries with a direct query
        :param : delete_only_files : if set to True, only files are deleted, not the db entries
        :returns: nothing
        """
        
        if delete_only_files:
            delete_files=True
            
        if mrn is not None:
            if delete_files == True:
                log.error('Cannot delete on mrn and physically delete the files')
                return (-1)
            else:
                self.execute_db_query(query='delete from dicomimages where imagepat="{}"'.format(mrn))
                self.execute_db_query(query='delete from dicomseries where seriespat="{}"'.format(mrn))
                self.execute_db_query(query='delete from dicomstudies where PatientID="{}"'.format(mrn))
                self.execute_db_query(query='delete from dicompatients where PatientID="{}"'.format(mrn))

                log.info('Deleted all database entries for patient {} from the database tables'.format(mrn))
                return (1)

        if query is not None:
            log.info('deleting series following query: {}'.format(query))
            result = self.execute_db_query(query)
            serieslist = [d['SeriesInst'] for d in result]
            self.delete_series(seriesuid=serieslist, delete_files=delete_files, delete_only_files=delete_only_files)
            return ()

        if isinstance(seriesuid, list):  # recursive call in case of list as input
            for suid in seriesuid:
                self.delete_series(seriesuid=suid, delete_files=delete_files, delete_only_files=delete_only_files)
            return ()

        # single seriesuid given
        else:
            file_query = "select ObjectFile,ImagePat,dicomseries.StudyInsta from dicomimages \
                            inner join dicomseries on (dicomseries.SeriesInst = dicomimages.seriesinst) \
                            where dicomimages.seriesinst==\"{}\"".format(seriesuid)

            return_list = self.execute_db_query(file_query)
            if (len(return_list) == 0):
                log.info('no images found for this seriesuid : ' + seriesuid)
                return

            for row in return_list:
                studyuid = row['StudyInsta']
                patientid = row['ImagePat']
                filename = "{}/{}".format(self.data_directory, row['ObjectFile'])
                if os.path.exists(filename):
                    if delete_files:
                        os.remove(filename)
                        log.info('deleting ' + filename)
                    else:
                        log.info('not deleting file, only DB entries,  since delete_files=False'.format(filename))
                else:
                    log.error("The file you want to delete does not exist")

                # delete dicomimage table entry
                if not delete_only_files:
                    query = 'delete from dicomimages where ObjectFile="{}"'.format(row['ObjectFile'])
                    self.execute_db_query(query)

            if not delete_only_files:
                # delete dicomseries table entry
                query = 'delete from dicomseries where seriesinst="{}"'.format(seriesuid)
                self.execute_db_query(query)

                # now delete the study entry in db if this is the last ...
                query_for_remaining_series = 'select count(*) as nr from dicomseries where studyinsta="{}"'.format(studyuid)
                remaining_series = self.execute_db_query(query_for_remaining_series)
                if remaining_series[0]['nr'] == 0:
                    query = 'delete from dicomstudies where StudyInsta="{}"'.format(studyuid)
                    self.execute_db_query(query)
                    log.info('no more series : now deleting studiuid entry in db : {}'.format(studyuid))

                query_for_remaining_studies = 'select count(*) as nr from dicomstudies where PatientID="{}"'.format(
                    patientid)
                remaining_studies = self.execute_db_query(query_for_remaining_studies)
                if remaining_studies[0]['nr'] == 0:
                    query = 'delete from dicompatients where PatientID="{}"'.format(patientid)
                    self.execute_db_query(query)
                    log.info('no more studies : now deleting patient db entry with number : {}'.format(patientid))


    #
    #   Some utility routines not part of base functionality of conquest, but handy
    #

    def copy_dicom_files_to_dest(self, seriesuid=None, query=None, destination='', CreateDir=True,
                                 UseSubDirectories=False):
        """Copies all dicom files belonging to a series to destination, described by either a seriesuid or a query.

        :param: serieuid : a single string (one seriesuid) or a list of seriesuids of series that should be copied
        :param: query  : should be a query for seriesuids, the query should return at least one column : SeriesInst
        :param: CreateDir : determines of a directory is created if it does not exist ( default = True)
        :param: UseSubDirectories : determines if when storig subdirectories with the name PatientID are used ( default=False)
        """

        if not seriesuid is None:
            if isinstance(seriesuid, list):  # recursive call in case of list as input
                for suid in seriesuid:
                    self.copy_dicom_files_to_dest(seriesuid=suid, destination=destination,
                                                  CreateDir=CreateDir, UseSubDirectories=UseSubDirectories)
                return
            else:
                file_query = "select ObjectFile,ImagePat from dicomimages where seriesinst=\"{}\"".format(seriesuid)
                return_list = self.execute_db_query(file_query)
        elif not query is None:
            series_list = self.execute_db_query(query)
            for row in series_list:
                suid = row['SeriesInst']
                self.copy_dicom_files_to_dest(seriesuid=suid, destination=destination,
                                              CreateDir=CreateDir, UseSubDirectories=UseSubDirectories)
            return
        else:
            log.error('As yet unimplemented option in copy_dicom_files_to_dest')
            return -1

        if return_list and CreateDir:
            if not os.path.exists(destination):
                os.makedirs(destination)
                log.info("Directory " + destination + " Created ")

        list_of_filenames = []
        if not UseSubDirectories:
            for row in return_list:
                filename = "{}/{}".format(self.data_directory, row['ObjectFile'])
                log.info('copying ' + filename + ' to dest : ' + destination)
                shutil.copy(filename, destination)
                list_of_filenames.append(destination+'/'+os.path.basename(row['ObjectFile']))
        else:
            for row in return_list:
                filename = "{}/{}".format(self.data_directory, row['ObjectFile'])
                destination_patientdir = "{}/{}".format(destination, row['ImagePat'])
                if not os.path.exists(destination_patientdir):
                    os.makedirs(destination_patientdir)
                    log.info("Directory " + destination_patientdir + " Created ")
                log.info('copying ' + filename + ' to dest : ' + destination_patientdir)
                shutil.copy(filename, destination_patientdir)
        return list_of_filenames

    #
    #   Below is the dicom communication part using pynetdicom
    #

    def send_dicom(self, addres='127.0.0.1', port=5678, patientid='', seriesuid='', query='', ae_title=b'PYNETDICOM',
                   sending_ae_title=b'pyconquest'):
        """Sends dicom files via the dicom protocol to a (remote) destination, select on patientid, seriesuid or query

        :param: addres : IP address of the dicom destination (computer)
        :param: port : port number of the dicom destination
        :param: patientid : if given sends all files of this patient
        :param: serieuid : if given sends all files of this seriesuid
        :param: query : sends all files resulting from this query, should contain 1 column called SeriesInst with the seriesuid
        :param: ae_title : AE title of destination ( Default PYNETDICOM )
        :param: sending_ae_title : AE title of the sender (me) ( Default : pyconquest )
        """
        filename_list = []
        if not patientid == '':
            query = 'Select ObjectFile from DICOMimages where imagepat=\'{}\''.format(patientid)
        elif not seriesuid == '':
            query = 'Select ObjectFile from DICOMimages where seriesinst=\'{}\''.format(seriesuid)
        elif not query == '':
            series_list = self.execute_db_query(query=query)
            log.info('Now sending using query: {}'.format(query))
            for it in series_list:
                ser = it['SeriesInst']
                self.send_dicom(addres=addres, port=port, seriesuid=ser, ae_title=ae_title,
                                sending_ae_title=sending_ae_title)
            return

        # query for filenames and fill list of fienames
        result = self.execute_db_query(query)
        for line in result:
            filename_list.append(self.data_directory + '\\' + line['ObjectFile'])

        self.send_dicom_file(addres, port, filename_list, aetitle=ae_title, sending_ae_title=sending_ae_title)

    def send_dicom_file(self, addres, port, filename_list, aetitle=b'PYNETDICOM', sending_ae_title=b'pyconquest'):
        """Send a dicom file via DICOM protocol to a destination

        :param: addres : IP address of the dicom destination (computer)
        :param: port : port number of the dicom destination
        :param: filename_list : either a single file or a list of filenames to send
        :param: aetitle : AEtitle of destination ( Default PYNETDICOM )
        :param: sending_ae_title : AE title of the sender (me) ( Default : pyconquest )
        """
        # Initialise the Application Entity
        ae = AE(ae_title=sending_ae_title)

        # Add a requested presentation context
        ae.requested_contexts = StoragePresentationContexts

        assoc = ae.associate(addres, port, ae_title=aetitle)
        if assoc.is_established:
            # Use the C-STORE service to send the dataset
            # returns the response status as a pydicom Dataset
            for filename in filename_list:
                ds = dcmread(filename)
                status = assoc.send_c_store(ds)

                # Check the status of the storage request
                if status:
                    # If the storage request succeeded this will be 0x0000
                    log.info('C-STORE request status: 0x{0:04x}'.format(status.Status))
                else:
                    log.error('Connection timed out, was aborted or received invalid response')

            # Release the association
            assoc.release()
        else:
            if assoc.is_rejected:
                msg = ('{0}: {1}'.format(
                    assoc.acceptor.primitive.result_str,
                    assoc.acceptor.primitive.reason_str
                ))
                log.error(msg)
            else:
                log.error('Association aborted or never connected')

    def __log_open_dcm_connection(self, event):
        """Print the remote's (host, port) when connected."""
        msg = 'Connected with remote (host, port) : {} : {}'.format(event.address, event.assoc.remote)
        # msg = 'Connected with remote (host, port) : {} : {}'.format(event.address, event.assoc.ae.ae_title)
        log.info(msg)

    def start_dicom_listener(self, port=5678, write_to_database=True, block=True):
        """Starts a listener following the dicom network protocol. Default behaviour is to store the received file in the database

        :param: port : portnumber
        :param: write_to_database : Determines whether the sql database is updated or not (Default True)
        """

        print('starting listener on port : ' + str(port))
        # update class variable that defines whether to write to database when receiving a file
        if write_to_database is True:
            self.__write_to_database_when_receiving_dicom_data = True
        else:
            self.__write_to_database_when_receiving_dicom_data = False
            print('Not updating the database when receiving data (write_to_database was set to False !)')

        handlers = [(evt.EVT_C_STORE, self.handle_dicom_store_request),
                    (evt.EVT_CONN_OPEN, self.__log_open_dcm_connection)]

        # Initialise the Application Entity
        ae = AE()
        # Support presentation contexts for all storage SOP Classes
        ae.supported_contexts = AllStoragePresentationContexts
        # Start listening for incoming association requests
        ae.start_server(('', port), block=block, evt_handlers=handlers)

    def handle_dicom_store_request(self, event):
        """Handle a C-STORE request event. Creates filename and saves the received dicom to this file. Then updates
        the database

        :param: event : event from the listener"""

        # Decode the C-STORE request's *Data Set* parameter to a pydicom Dataset
        ds = event.dataset

        # Add the File Meta Information
        ds.file_meta = event.file_meta
        patientid = ds[0x0010, 0x0020].value
        log.info('incoming DICOM communication event for patient : ' + str(patientid))

        filename = "{}/{}/{}.dcm".format(self.data_directory, patientid, ds.SOPInstanceUID)
        path = "{}/{}".format(self.data_directory, patientid)
        if not os.path.exists(path):
            os.makedirs(path)
            print("Directory " + path + " Created ")

        # Save the dataset using the SOP Instance UID as the filename
        ds.save_as(filename, write_like_original=False)
        log.info('dicom saved to file : ' + filename)

        if self.__write_to_database_when_receiving_dicom_data is True:
            # ds2 = dcmread(filename)
            c2 = pyconquest(database_filename=self.database_filename, data_directory=self.data_directory,
                            compute_hash=self.__compute_hash, loglevel='INFO')
            c2.__db_design = self.__db_design
            filename2 = "{}/{}".format(patientid, os.path.basename(filename))
            c2.write_tags(ds, filename2)
            c2.close_db()

        # Return a 'Success' status
        return 0x0000

    def query_dicom(self, addres='127.0.0.1', port=5678, ae_title='', patientid='', modality='', studyuid='', studydate='',
                    seriesuid='', sending_ae_title=b'PYCONQUEST'):
        """Queries a dicom server using C-FIND
                :param: addres : IP addres of dicom server where the query is done to
                :param: port : portnumber of dicom server where the query is done to
                :param: ae_title : ae title of dicom server where the query is done to
                :param: patientid : patientid, to query only for this patient
                :param: modality : modality (RTPLAN,RTSTRUCT etc. ) to query only for specific modality
                :param: studyuid : study to query (default all study uids)
                :param: seriesuid : series to query (default all study uids)
                :param: sending_ae_title : ae title of this node ( the requesting node )

                returns a list of dicts of the response
                """

        log.info('starting DICOM query (C-FIND) on port : ' + str(port) + ' of server : ' + str(addres))

        ae = AE(ae_title=sending_ae_title)
        ae.add_requested_context(PatientRootQueryRetrieveInformationModelFind)

        # Create our Identifier (query) dataset
        ds1 = dataset.Dataset()
        ds1.QueryRetrieveLevel = 'SERIES'
        ds1.PatientID = str(patientid)
        # adding empty items to the dataset makes that they are returned in the data
        ds1.SOPClassesInStudy = ''
        ds1.StudyInstanceUID = studyuid
        ds1.SeriesInstanceUID = seriesuid
        ds1.Modality = modality
        ds1.StudyDate = studydate
        ds1.StudyTime = ''
        ds1.SeriesDate = ''
        ds1.SeriesTime = ''
        ds1.SeriesDescription = ''
        ds1.StudyDescription = ''
        ds1.PatientBirthDate = ''
        ds1.StudyID = ''
        ds1.FrameOfReferenceUID = ''

        response_list = []
        response_counter = 0
        assoc = ae.associate(addres, port, ae_title=ae_title)
        if assoc.is_established:
            responses = assoc.send_c_find(ds1, PatientRootQueryRetrieveInformationModelFind)
            for (status, identifier) in responses:
                mydict = {}
                if status:
                    if status.Status not in [65280, 0]:  # these are normal statusses during transfer or at the end
                        log.error('C-GET query status: '.format(status.Status))

                    if identifier is not None:
                        mydict = {}
                        for item in identifier:
                            mydict.update({item.keyword: item.value})
                else:
                    log.error('Connection timed out, was aborted or received invalid response')
                if not mydict == {}:
                    response_list.append(mydict)
                    response_counter = response_counter + 1
            # Release the association
            assoc.release()
        else:
            log.error('Association rejected, aborted or never connected')

        log.info('DICOM C-FIND query returned {} response(s)'.format(response_counter))
        return response_list

    def get_dicom(self, addres='127.0.0.1', port=5678, ae_title='',
                  patientid='', modality='', series_uid='', sop_instance_uid='',
                  receiving_ae_title='PYCONQUEST', receiving_ip='', receiving_port_number=5699,
                  requesting_ae_title='PYCONQUEST',
                  association_timeout=60, sending_to_my_own_scp=True, unrestricted_storage=True, force_transfer=False):

        """Queries a dicom server using C-MOVE
                :param: addres : IP addres of dicom server where the query is done to
                :param: port : portnumber of dicom server where the query is done to
                :param: ae_title : ae title of dicom server where the query is done to

                :param: receiving_ae_title : ae title of node that is spun up on this machine to receive the data
                :param: receiving_ip : ip of node that is spun up on this machine to receive the data
                :param: receiving_port : port of node that is spun up on this machine to receive the data

                :param: requesting_ae_title : ae title of node that is requesting the MOVE (default PYCONQUEST)

                :param: patientid : patientid of data to get
                :param: modality : modality to get (RTPLAN,RTSTRUCT etc.)
                :param: series_uid : series UID of data to get
                :param: sop_instance_uid : sop instance UID of data to get

                :param: association_timeout : timeout in seconds to wait for the response, RTSTRUCT can be slow
                :param: sending_to_my_own_scp, if true (default) spin up your own receiving SCP to receive data
                :param: unrestricted_storage if true : allow all data to be received

                :return: the error code of the c-move command or None if there is no error
                """

        # Test if there is a sensible query, to prevent querying too much which can 'hang' the SCP
        if len(patientid) < 4 and len(series_uid) < 4 and len(sop_instance_uid) < 4:
            log.error('PatientID AND SeriesUID AND SopInstanceUID are not valid (< 4 char:so too short). '
                      'Query will not be executed')
            return

        # check if object is already in database, return if it is
        if len(series_uid) > 4 and force_transfer is False:
            if self.execute_db_query("select * from dicomseries where SeriesInst='{}'".format(series_uid)):
                log.info("Item with seriesuid:{} already in database, not retreiving it since force_transfer "
                         "is set to : False".format(series_uid))
                return

        if len(sop_instance_uid) > 4 and force_transfer is False:
            if self.execute_db_query("select * from dicomimages where SOPInstanc='{}'".format(sop_instance_uid)):
                log.info("Item with SOPInstance:{} already in database, not retreiving it since force_transfer "
                         "is set to : False".format(sop_instance_uid))
                return

        log.info('Starting querying for C-MOVE on SCP server {}/{}/{}'.format(ae_title, addres, port))

        # needed for instance to get RTPLANs from Eclipse into the system
        if unrestricted_storage:
            pynetdicom._config.UNRESTRICTED_STORAGE_SERVICE = True

        # spin up my own SCP to receive the data if requested
        if sending_to_my_own_scp:
            ae2 = AE()
            ae2.supported_contexts = AllStoragePresentationContexts
            ae2.maximum_pdu_size = 0
            handlers = [(evt.EVT_C_STORE, self.handle_dicom_store_request)]
            scp = ae2.start_server((receiving_ip, receiving_port_number), ae_title=receiving_ae_title,
                                   block=False, evt_handlers=handlers)

            log.info('This SCP server should have ae_title : {} defined with [ip of (this) localhost]/{}'
                     .format(receiving_ae_title, receiving_port_number))

        # Create our Identifier (query) dataset
        ds1 = dataset.Dataset()
        ds1.QueryRetrieveLevel = 'SERIES'
        ds1.PatientID = str(patientid)
        ds1.Modality = modality
        ds1.SeriesInstanceUID = series_uid
        ds1.SOPInstanceUID = sop_instance_uid

        # create request
        ae = AE(ae_title=requesting_ae_title)
        ae.add_requested_context(PatientRootQueryRetrieveInformationModelMove)
        ae.supported_contexts = AllStoragePresentationContexts

        assoc = ae.associate(addres, port, ae_title=ae_title)
        assoc.acse_timeout = association_timeout
        assoc.dimse_timeout = association_timeout
        assoc.network_timeout = association_timeout
        cmove_status_explananation = {0xc003: 'AE to send to is not known by the SCP',
                                      0xc004: 'Requested item not found by the SCP',
                                      0xc005: 'No connection between SCP and receiver (port or ip wrong ?)'}
        error_code = None
        if assoc.is_established:
            log.info('Now sending C-MOVE request to send from {}/{} to {}'.format(addres, port,
                                                                                receiving_ae_title))
            responses = assoc.send_c_move(ds1, receiving_ae_title, PatientRootQueryRetrieveInformationModelMove)
            for (status, identifier) in responses:
                if status:
                    if status.Status not in [65280, 0]:  # these are normal statusses during transfer or at the end
                        log.error('C-MOVE query status: 0x{0:04x} : {1}'.format(status.Status,
                                                        cmove_status_explananation.get(status.Status, 'Unknown Error')))
                        error_code = status.Status
                else:
                    log.error('Connection timed out, was aborted or received invalid response')
            # Release the association
            assoc.release()
        else:
            log.error('Association rejected, aborted or never connected')
            error_code = 'ERROR : No DICOM connection could be established with {}'.format(ae_title)
        log.info('Finishing C-MOVE, now stopping the receiver')
        if sending_to_my_own_scp:
            scp.shutdown()
        return error_code

    #
    # examine database
    #

    def dicom_series_summary(self, orderby='nrCT', print_summary=True):
        """Returns a summary of the database contents ( number of elements ) in the form of a list of dicts
        if print_summary is True, the result is printed to stdout
        alternatively : to 'pretty print' use : print(pd.DataFrame(c.dicom_series_summary()))

        :param orderby : defines sorting order, give here the name of the column, is directly insterted in query
        :type orderby : string
        :param print_summary : if True (default) the summary is printed
        """

        query = "select distinct patientid " \
                ",(select count(*) from dicomseries where seriespat=patientid and modality=\'CT\') as nrCT" \
                ",(select count(*) from dicomseries where seriespat=patientid and modality=\'MR\') as nrMR" \
                ",(select count(*) from dicomseries where seriespat=patientid and modality=\'PT\') as nrPT" \
                ",(select count(*) from dicomseries where seriespat=patientid and modality=\'RTSTRUCT\') as nrRTSTRUCT" \
                ",(select count(*) from dicomseries where seriespat=patientid and modality=\'RTDOSE\') as nrRTDOSE" \
                ",(select count(*) from dicomseries where seriespat=patientid and modality=\'RTPLAN\') as nrRTPLAN" \
                " from dicompatients order by {}".format(orderby)
        result = self.execute_db_query(query)

        if print_summary:
            print('    PatientID    nrCT nrMR  nrPT nrRTSTRUCT nrRTDOSE nrRTPLAN')
            rowcount = 0
            for r in result:
                rowcount = rowcount + 1
                print('{}{}{}{}{}{}{}{}'.format(str(rowcount).ljust(5),
                                                r['PatientID'].ljust(14),
                                                str(r['nrCT']).ljust(5),
                                                str(r['nrMR']).ljust(5),
                                                str(r['nrPT']).ljust(8),
                                                str(r['nrRTSTRUCT']).ljust(10),
                                                str(r['nrRTDOSE']).ljust(10),
                                                str(r['nrRTPLAN']).ljust(8)))

        return result

    # some utility functions that are handy to have in the base class

    def dump_data_to_csv(self, query=None, table='dicomseries', filename_dict=None, filename='query_dump.csv',
                         delimiter=','):
        """
        Dump database tables to csv

        Dumps tables or views or the result of a query to a csv file

        :param query: if defined, the result of the query is saved to file default : None
        :param table: a tablename or list of tablenames to dump to file : default : dicomseries
        :param filename_dict: a dict to define for each table/view a filename, default : None
        :param filename: a string defining the filename when using the query mode : default : 'query_dump.csv'
        :param delimiter: delimeter to use when generating csv file
        :return None:
        """
        if isinstance(table, list):
            for t in table:
                self.dump_data_to_csv(table=t, filename_dict=filename_dict, delimiter=delimiter)
            return

        if query is None:
            query = 'select * from {}'.format(table)
            csv_filename = '{}.csv'.format(table)
            if filename_dict is not None:
                if table in filename_dict:
                    csv_filename = '{}.csv'.format(filename_dict[table])
                    print(csv_filename)
        else:
            csv_filename = filename
            table = 'dedicated query'

        result = self.execute_db_query(query=query)

        if len(result) > 0:
            keys = result[0].keys()
            with open(csv_filename, 'w', newline='') as output_file:
                dict_writer = csv.DictWriter(output_file, keys, delimiter=delimiter)
                dict_writer.writeheader()
                dict_writer.writerows(result)
            log.info('wrote {} to {}'.format(table, csv_filename))

    def analyse_images(self, list_of_seriesuid=None):
        """Analyses images for number of slices and min/max sliceposition and enters the result in DICOMseries table

        :param : list_of_seriesuid : list of seriesuid or single seriesuid, if NONE all images are analysed
        :returns : list of seriesuid where an inconsistency is found in the slice distances
        """
        for colname in ['N_slices', 'min_sliceposition', 'max_sliceposition', 'ScanRange', 'SliceThickness',
                        'UniqueSliceDistance']:
            append_query = 'alter table dicomseries add {} character varying(128)'.format(colname)
            self.execute_db_query(append_query)
            log.info('appended column {} to dicomseries table'.format(colname))

        if list_of_seriesuid is None:
            query = "select SeriesInst from dicomseries where modality in ('CT','MR','PT')"
            list_of_seriesuid = self.execute_db_query(query, return_list_from_col='SeriesInst')
        elif isinstance(list_of_seriesuid, str):
            list_of_seriesuid = [list_of_seriesuid]

        seriesinst_with_inconsistent_slicedistances = []
        for seriesinst in list_of_seriesuid:
            query = "select count(*) as N_slices," \
                    "min(CAST(slicelocat as float)) as min_sliceposition, " \
                    "max(CAST(slicelocat as float)) as max_sliceposition, " \
                    "abs(min(CAST(slicelocat as float))-max(CAST(slicelocat as float))) as ScanRange, " \
                    "max(CAST(slicethick as float)) as SliceThickness " \
                    "from dicomimages as di where di.SeriesInst='{}'".format(seriesinst)
            result = self.execute_db_query(query)
            if result[0]['N_slices'] == 0:
                log.error('Found zero slices in query for series: {} '.format(seriesinst))
                continue

            # check consistency of slice distances
            query_for_slicedistance_consistency = """
                select 
                (select min(CAST(d2.slicelocat as float)) from dicomimages as d2 where d2.SeriesInst=d1.SeriesInst and 
                CAST(d2.slicelocat as float)>CAST(d1.slicelocat as float))-CAST(d1.slicelocat as float) as diff_to_next_slicelocat
                from dicomimages as d1 where d1.SeriesInst='{}' order by CAST(d1.slicelocat as float)
            """.format(seriesinst)
            result2 = self.execute_db_query(query_for_slicedistance_consistency,
                                            return_list_from_col='diff_to_next_slicelocat')
            # leave only unique values and remove the None-s (last slice has no slice distance to next slice ...
            result2 = [i for i in result2 if i is not None]
            result2 = [round(float(num), 1) for num in result2]
            result2 = list(dict.fromkeys(result2))

            if (len(result2)) == 1:
                result[0]['UniqueSliceDistance'] = result2[0]
            else:
                log.error('Non Uniform slicedistance for series: {}; found {} '.format(seriesinst, result2))
                result[0]['UniqueSliceDistance'] = "''"
                seriesinst_with_inconsistent_slicedistances.append(seriesinst)

            log.info('Adding slice info to dicomseries table for series: {} '.format(seriesinst))
            for item, value in result[0].items():
                query2 = "update dicomseries set {}={} where seriesInst='{}'".format(item, value, seriesinst)
                self.execute_db_query(query2)

        return seriesinst_with_inconsistent_slicedistances

    def set_roi_filter(self, exclude=[''], include=[''], roi_filter_flags=re.IGNORECASE):
        """sets the exclude and include filters for the roi names

        :param: exclude : string or list of strings, each describing and exclusion
        :param: include : string or list of strings, describe the rois to include, '' is : include all
        :param: roi_filter_flags : flags for the re module, DEFAULT : re.IGNORECASE, set flags=0 to clear flags

        exclude is run before include filter
        """
        # if only a string is given, put it in a list
        if isinstance(exclude, str):
            exclude = [exclude]
        if isinstance(include, str):
            include = [include]

        self.exclude_filter = exclude
        self.include_filter = include
        self.roi_filter_flags = roi_filter_flags
        log.info(
            'Filtervalues :  include: {} ; exclude {} ; flags : {}'.format(self.include_filter, self.exclude_filter,
                                                                           str(self.roi_filter_flags)))

    def filter_roinames(self, roinames):
        """Drops all roinames in the list exclude_patterns, then only includes the ones in list include_patterns
        use the set_roifilter method to set the filter parameters

        Parameters:
            roinames: list of roinames to filter
            flags : flags to regexp, default is IGNORECASE

        Return:
            filtered list of roinames
        """
        returnlist = []
        # the if statement is because when the pattern is empty string, everything is matched in re
        if self.exclude_filter[0] != '':
            for pattern in self.exclude_filter:
                p = re.compile(pattern, self.roi_filter_flags)
                roinames = [roiname for roiname in roinames if not p.match(roiname)]

        for pattern in self.include_filter:
            p = re.compile(pattern, self.roi_filter_flags)
            for roiname in roinames:
                if p.match(roiname):
                    returnlist.append(roiname)

        return returnlist

    def __create_db_views(self):
        v_series = '''
            create view v_series as
            select dicomseries.*,dicomstudies.*
            from DICOMseries
            inner join dicomstudies on dicomseries.StudyInsta=dicomstudies.StudyInsta
        '''
        v_seriesRT = '''
            create view v_seriesRT as
            select dicomseries.*,dicomstudies.*,dicomimages.* 
            from DICOMseries
            inner join dicomstudies on dicomseries.StudyInsta=dicomstudies.StudyInsta
            inner join dicomimages on dicomimages.seriesinst=dicomseries.seriesinst 
            where DICOMseries.modality in ('RTSTRUCT','RTDOSE','RTPLAN')
        '''

        self.execute_db_query('DROP VIEW IF EXISTS v_series')
        self.execute_db_query(v_series)
        self.execute_db_query('DROP VIEW IF EXISTS v_seriesRT')
        self.execute_db_query(v_seriesRT)
        log.info('Created views : v_series and v_seriesRT')
        return 1

    def __create_db_index_tables(self):
        """Creates database index tables to speed up queries"""

        index_dicomimages = \
            'CREATE INDEX IF NOT EXISTS "index_dicomimages" ON "DICOMimages" ("SOPInstanc")'
        index_dicomseries = \
            'CREATE INDEX IF NOT EXISTS "index_dicomseries" ON "DICOMseries" ("SeriesInst")'
        index_dicomimages_seriesinst = \
            'CREATE INDEX IF NOT EXISTS "index_dicomimages_seriesinst" ON "DICOMimages" ("SeriesInst")'
        self.execute_db_query(index_dicomimages)
        self.execute_db_query(index_dicomseries)
        self.execute_db_query(index_dicomimages_seriesinst)
        log.info('Created index_dicomimages and index_dicomseries')

    def database_postprocessing(self):
        """
        postprocesses the database to enrich the database for entries that can only be added when the database is
        complete.
        Updates the Referenced seriesuid -> DICOMseries.Referenced for RTDOSE and RTPLAN
        :return: None
        """

        query_to_fill_Referenced_for_RTDOSE = """
        update dicomseries set referenced=
            (
            select d2.seriesinst from dicomimages as d1 
            inner join dicomimages as d2 on d2.SOPInstanc=d1.ReferencedSOPUID
            where d1.seriesinst=dicomseries.seriesinst limit 1
            )
        where modality in ('RTDOSE','RTPLAN')
        """
        # self.execute_db_query(query_to_fill_Referenced_for_RTDOSE)
        log.info('postprocessing of database done')

    #
    #   some routines to modify tags in a file
    #

    def change_tag(self, filename, tag='PatientBirthDate', new_value='19000101', create=False):
        '''change tag of a dicom file

        :param filename: full path of filename of the file to change (so incl for instance : 'data/MRN/...dcm'
        :param tag: tag can be the name/description of the tag, or a tuble defining the element ('0x0010','0x0030')
        :param new_value: new value of the tag
        :param create: it a tag (defined by tuple) is not present, the tag is created with the new value
        if create=True ( default=False )
        :return: 1=succes, -1 is not succesfull
        '''
        try:
            ds = dcmread(filename)
            if isinstance(tag, str):
                if tag in ds:
                    ds.data_element(tag).value = new_value
                    log.info('now saving : {} with {} changed to {}'.format(filename, tag, new_value))
                else:
                    log.error('tag {} not in file : {}'.format(tag, filename))
                    return -1

            if isinstance(tag, tuple):
                if tag in ds:
                    ds[tag].value = new_value
                    log.info('now saving : {} with {} changed to {}'.format(filename, tag, new_value))
                elif create:
                    ds.add_new(tag, 'LT', new_value)  # LO is long string(64 char max), LT is long text (10240 mx)
                    log.info('now created : {} with {} changed to {}'.format(filename, tag, new_value))
                else:
                    log.error('element {} not found, set create=True to create the tag'.format(tag))
                    return -1

            ds.save_as(filename)
            return 1
        except Exception as e:
            log.error('error {} in writing tag {} to file {}'.format(str(e), tag, filename))

    def get_list_of_filenames(self, filename=None, seriesuid=None, studyuid=None):
        """ Returns a list of filenames, input is either a single or a list of filenames, or a single seriesuid or a
            list of series uids. In the future also studyuid and patientid ?
        """

        if filename is not None:
            if isinstance(filename, list):
                return filename
            else:
                return [filename]
        elif seriesuid is not None or studyuid is not None:
            if isinstance(seriesuid, str):
                seriesuid = [seriesuid]
            if isinstance(studyuid, str):
                studyuid = [studyuid]
            if seriesuid is not None:
                query = 'select ObjectFile from dicomimages where seriesinst="{}"'
                uidlist = seriesuid
                log.info('creating filelist derived from seriesuid or list of seriesuids')
            else:
                query = '''select di.ObjectFile from dicomimages as di
                            inner join dicomseries as ds on di.seriesinst=ds.seriesinst
                            where ds.studyinsta="{}"'''
                uidlist = studyuid
                log.info('creating filelist derived from studyuid or list of studyuids')

            returnlist = []
            for uid in uidlist:
                q = query.format(uid)
                result = self.execute_db_query(q)
                filelist = ['{}\{}'.format(self.data_directory, d['ObjectFile']) for d in result]
                returnlist = returnlist + filelist
            return returnlist

    def change_all_tags(self, filename=None, seriesuid=None, studyuid=None,
                        tag='PatientBirthDate', new_value='19000101', create=False):

        list_of_filenames = self.get_list_of_filenames(filename=filename, seriesuid=seriesuid, studyuid=studyuid)
        for fn in list_of_filenames:
            self.change_tag(filename=fn, tag=tag, new_value=new_value, create=create)

    def modify_rtstruct(self, filename, mode, roiname, newname='', write_file=False, delete_points=False):
        ''' Modifies an rtstruct file by changing or deleting roi's

        :param filename: filename of file to process
        :param mode: can be change ( to change roi name ), delete ( to delete roi's ) or leave ( to delete all but the
        names defined in list roiname
        :param roiname: list of roi names to change/delete or leave after processing
        :param newname: only for change mode : list of new names, list should be of equal length as 'roinames'
        :param write_file: defines whether to actually replace the file (default False)
        :param delete_points: defines wether to delete points in the leave mode ( default False )
        :return: pydicom dataset
        '''
        if mode not in ['leave', 'change', 'delete']:
            log.error('mode {} not known, choose from : change,leave or delete'.format(mode))
            return

        # check consistency of old/new names
        if len(roiname) != len(newname) and mode == 'change':
            log.error('Lengths of roiname and newname are not equal : {} // {}'.format(roiname, newname))
            return -1

        # if the filename is a list, do a recursive call to this same routine with every element of the list
        if isinstance(filename, list):
            for fn in filename:
                self.modify_rtstruct(filename=fn, mode=mode, roiname=roiname, newname=newname,
                                     write_file=write_file, delete_points=delete_points)
            return -1

        try:
            ds = dcmread(filename)
            dicomtype = ds[0x0008, 0x0060].value
            if dicomtype == 'RTSTRUCT':
                contours = ds[0x3006, 0x0020].value
                roicounter = 0
                contourindices_not_in_roinames = []
                contourindices_to_delete = []
                for c in contours:
                    if c[0x3006, 0x0026].value in roiname:
                        index = roiname.index(c[0x3006, 0x0026].value)
                        if mode == 'change':
                            ds[0x3006, 0x0020][roicounter][0x3006, 0x0026].value = newname[index]
                        elif mode == 'delete':
                            log.info('deleting : ind : {}, name {}'.format(roicounter, c[0x3006, 0x0026].value))
                            contourindices_to_delete.append(roicounter)
                    else:
                        contourindices_not_in_roinames.append(roicounter)
                    roicounter = roicounter + 1

                if mode == 'leave' or 'delete':
                    if mode == 'leave':
                        contourindices_to_delete = contourindices_not_in_roinames
                    log.info('Modus {} : will delete indices {}'.format(mode, contourindices_to_delete))
                    shift = 0  # during the deletion the indices are shifting downwards
                    for i in contourindices_to_delete:
                        #to catch situation where structure is empty
                        try:
                            roitype = ds[0x3006, 0x0039][i - shift][0x3006, 0x0040][0][0x3006, 0x0042].value
                            roiname = ds[0x3006, 0x0020][i - shift][0x3006, 0x0026].value
                        except:
                            roitype='>could not extract roitype, maybe it is empty<'
                            roiname='>could not extract roiname, maybe it is empty<'
                        if not ((str(roitype) == 'POINT' and delete_points == False) and mode == 'leave'):
                            log.info('deleting: {} of type {}'.format(roiname, str(roitype)))
                            del ds[0x3006, 0x0020].value[i - shift]
                            del ds[0x3006, 0x0039].value[i - shift]
                            del ds[0x3006, 0x0080].value[i - shift]
                            shift = shift + 1
                if write_file:
                    ds.save_as(filename)
                    log.info('Saved to : {} '.format(filename))
                return ds
            else:
                log.error('not an RTSTRUCTFILE : {}'.format(filename))

        except Exception as e:
            log.error('Error {} file : {} '.format(str(e), filename))

    #
    # default database format
    #

    def __set_default_database(self):
        log.info('Using default database layout,specify .sql file during instance creation to change this')
        self.__db_design = \
            {'DICOMpatients':
                 [['0x0010', '0x0020', 'PatientID'],
                  ['0x0010', '0x0010', 'PatientNam'],
                  ['0x0010', '0x0030', 'PatientBir'],
                  ['0x0010', '0x0040', 'PatientSex']],
             'DICOMstudies':
                 [['0x0020', '0x000d', 'StudyInsta'],
                  ['0x0008', '0x0020', 'StudyDate'],
                  ['0x0008', '0x0030', 'StudyTime'],
                  ['0x0020', '0x0010', 'StudyID'],
                  ['0x0008', '0x1030', 'StudyDescr'],
                  ['0x0008', '0x0050', 'AccessionN'],
                  ['0x0008', '0x0090', 'ReferPhysi'],
                  ['0x0010', '0x1010', 'PatientsAg'],
                  ['0x0010', '0x1030', 'PatientsWe'],
                  ['0x0008', '0x0061', 'StudyModal'],
                  ['0x0010', '0x0010', 'PatientNam'],
                  ['0x0010', '0x0030', 'PatientBir'],
                  ['0x0010', '0x0040', 'PatientSex'],
                  ['0x0008', '0x1070', 'OperatorsN'],
                  ['0x0010', '0x0020', 'PatientID']],
             'DICOMseries':
                 [['0x0020', '0x000e', 'SeriesInst'],
                  ['0x0020', '0x0011', 'SeriesNumb'],
                  ['0x0008', '0x0021', 'SeriesDate'],
                  ['0x0008', '0x0031', 'SeriesTime'],
                  ['0x0008', '0x103e', 'SeriesDesc'],
                  ['0x0008', '0x0060', 'Modality'],
                  ['0x0008', '0x1090', 'ManModelNa'],
                  ['0x0008', '0x1155', 'Referenced'],
                  ['0x0018', '0x5100', 'PatientPos'],
                  ['0x0018', '0x0010', 'ContrastBo'],
                  ['0x0008', '0x0070', 'Manufactur'],
                  ['0x0018', '0x0015', 'BodyPartEx'],
                  ['0x0018', '0x1030', 'ProtocolNa'],
                  ['0x0008', '0x1010', 'StationNam'],
                  ['0x0008', '0x0080', 'Institutio'],
                  ['0x0020', '0x0052', 'FrameOfRef'],
                  ['0x0028', '0x0008', 'NumberOfFr'],
                  ['0x3004', '0x000A', 'DoseSummat'],
                  ['0x3006', '0x0002', 'StructureS'],
                  ['0x0010', '0x0020', 'SeriesPat'],
                  ['0x0008', '0x1070', 'OperatorsN'],
                  ['0x0020', '0x000d', 'StudyInsta']],
             'DICOMimages':
                 [['0x0008', '0x0018', 'SOPInstanc'],
                  ['0x0008', '0x0016', 'SOPClassUI'],
                  ['0x0020', '0x0013', 'ImageNumbe'],
                  ['0x0008', '0x0023', 'ImageDate'],
                  ['0x0008', '0x0033', 'ImageTime'],
                  ['0x0008', '0x1155', 'Referenced'],
                  ['0x0018', '0x0086', 'EchoNumber'],
                  ['0x0028', '0x0008', 'NumberOfFr'],
                  ['0x0008', '0x0022', 'AcqDate'],
                  ['0x0008', '0x0032', 'AcqTime'],
                  ['0x0018', '0x1250', 'ReceivingC'],
                  ['0x0020', '0x0012', 'AcqNumber'],
                  ['0x0020', '0x1041', 'SliceLocat'],
                  ['0x0028', '0x0002', 'SamplesPer'],
                  ['0x0028', '0x0004', 'PhotoMetri'],
                  ['0x0028', '0x0010', 'Rows'],
                  ['0x0028', '0x0011', 'Colums'],
                  ['0x0028', '0x0030', 'PixelSpaci'],
                  ['0x0028', '0x0101', 'BitsStored'],
                  ['0x0028', '0x1052', 'RescaleInt'],
                  ['0x0028', '0x1053', 'RescaleSlo'],
                  ['0x0008', '0x0008', 'ImageType'],
                  ['0x0054', '0x0400', 'ImageID'],
                  ['0x0010', '0x0020', 'ImagePat'],
                  ['0x0018', '0x0060', 'KVP'],
                  ['0x0018', '0x1150', 'ExposureTi'],
                  ['0x0018', '0x1151', 'TubeCurren'],
                  ['0x0018', '0x1152', 'Exposure'],
                  ['0x0018', '0x9345', 'CTDIvol'],
                  ['0x01F1', '0x1026', 'Pitch'],
                  ['0x01F1', '0x1027', 'RotationTi'],
                  ['0x01F1', '0x104A', 'DoseRight'],
                  ['0x01F1', '0x104B', 'Collimatio'],
                  ['0x0018', '0x0050', 'SliceThick'],
                  ['0x0020', '0x0037', 'ImageOrien'],
                  ['0x0008', '0x0060', 'Modality'],
                  ['0x0008', '0x103e', 'SeriesDesc'],
                  ['0x0020', '0x0032', 'ImagePosit'],
                  ['0x0020', '0x000e', 'SeriesInst']],
             'DICOMworklist':
                 [['0x0008', '0x0050', 'AccessionN'],
                  ['0x0010', '0x0020', 'PatientID'],
                  ['0x0010', '0x0010', 'PatientNam'],
                  ['0x0010', '0x0030', 'PatientBir'],
                  ['0x0010', '0x0040', 'PatientSex'],
                  ['0x0010', '0x2000', 'MedicalAle'],
                  ['0x0010', '0x2110', 'ContrastAl'],
                  ['0x0020', '0x000d', 'StudyInsta'],
                  ['0x0032', '0x1032', 'ReqPhysici'],
                  ['0x0032', '0x1060', 'ReqProcDes'],
                  ['0x0040', '0x0100', '--------'],
                  ['0x0008', '0x0060', 'Modality'],
                  ['0x0032', '0x1070', 'ReqContras'],
                  ['0x0040', '0x0001', 'ScheduledA'],
                  ['0x0040', '0x0002', 'StartDate'],
                  ['0x0040', '0x0003', 'StartTime'],
                  ['0x0040', '0x0006', 'PerfPhysic'],
                  ['0x0040', '0x0007', 'SchedPSDes'],
                  ['0x0040', '0x0009', 'SchedPSID'],
                  ['0x0040', '0x0010', 'SchedStati'],
                  ['0x0040', '0x0011', 'SchedPSLoc'],
                  ['0x0040', '0x0012', 'PreMedicat'],
                  ['0x0040', '0x0400', 'SchedPSCom'],
                  ['0x0040', '0x0100', '---------'],
                  ['0x0040', '0x1001', 'ReqProcID'],
                  ['0x0040', '0x1003', 'ReqProcPri']]}
